#ifndef GAMEMANAGER_H
#define GAMEMANAGER_H
#include <iostream>
#include <time.h>
#include <conio.h>
#include <string>
#include "Terrain.h"

class GameManager
{
private:


public:
	GameManager(int w, int h);
	~GameManager();

};

#endif